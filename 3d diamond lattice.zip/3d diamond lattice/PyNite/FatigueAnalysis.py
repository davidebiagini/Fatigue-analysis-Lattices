# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 10:38:08 2019

@author: davidebiagini
"""

#Fatigue analysis Class for fast vectorizing

#from numpy import zeros, delete, insert, matmul, subtract
#from numpy.linalg import inv
#import statistics
import numpy as np

# %%
class FatigueAnalysis():
    
    
    def __init__(self,Smax,Smin,D):
    
              self.SMax = Smax
              self.SMin = Smin         
              self.Damage = D               

        
#    def AddStressMax(self, value):        
#        # Add the new stress to the list
#        self.SMax.append(value)
        
#%%       
#    def AddStressMin(self, value):        
#        # Add the new stress to the list
#        self.SMin.append(value)    
#        
#
##%%           
#    def AddDamage(self, value):        
#        # Add the new stress to the list
#        self.Damage.append(value)    


# %%    
    def Correct_Stress_cycle(self,Smax,Smin):  # In the case of Fatigue testing This function corrects Smax Smin in order to have the element Max and
                                               # Min stress instead of the specimen max and min stress (they not always correspond)       
        S=[]
        s=[]
        
        for i in range(len(Smax)):
            if Smax[i] >= Smin[i]:
               S.append(Smax[i])
               s.append(Smin[i])
               
            if Smax[i] < Smin[i]:
               s.append(Smax[i])
               S.append(Smin[i])
               
        return S,s       


# %% 
    def MeanStressCorrection(self,Smax,Smin,Yeld):  #Goodman Relation is used
        
        
        DS=np.subtract(Smax,Smin)*0.5
        MeanStress=(np.add(Smin,Smax))*0.5           
        Sigmaeff= np.multiply(DS,1/(1 - MeanStress*(Yeld**(-1))))
        
#        for i in range(len(Sigmaeff)):
#         if Sigmaeff[i] < 0 :
#             Sigmaeff[i] = 870
        
        return Sigmaeff,DS
    
#%%        
    def MinerRule(self,C,Sigmaeff,b,D):     
        import math as mt
        vec=[]
        for i in range(len(Sigmaeff)):
             if Sigmaeff[i]<0:
                 Sigmaeff[i]=1
             vec.append(mt.log10(Sigmaeff[i]))
        n=[]
        for i in range(len(Sigmaeff)):
             n.append(10**(12.5767-3.08737*vec[i])) #Basquin interpolation from SN
            
        n=np.asarray(n) 
#       n=np.power(C*Sigmaeff,b)  #Basquin exponential


        
        for i in range(len(n)):
           if Sigmaeff[i]<=130:
                n[i]=10e7
           if Sigmaeff[i]>=800:
                n[i]=10e3    
                
        for i in range(len(n)):
            if np.isnan(n[i]):
                n[i]=1e150
        
    
        N=np.multiply(n,(1-D))    # Vector of remaining life                
        Nmin=np.nanmin(N)         # Minimum remaining life element life            
        d = Nmin*np.power(n,-1)     # Damage vector updating
        
        return Nmin,d,N 

#%%        
    def FailureAnalysis(self,C,b,el_ids):
        
     
        Yeld=870
        Sigmaeff,DS=self.MeanStressCorrection(self.SMax,self.SMin,Yeld)   
       
        index=0
        for i in range(len(Sigmaeff)):
            if Sigmaeff[i]>= 870:
                index=1
       
        C=1/860
        b=-(1/0.04603)
          #  )
        
        # Two different Models for Static and Fatigue failure
        if index == 0:

                Nmin,d,N=self.MinerRule(C,Sigmaeff,b,self.Damage)
                for i in range(len(d)):
                  if np.isnan(d[i])==True:
                   d[i] = 0    
                
                d=self.Damage+d        
                rem=np.nanargmin(N)
                d=np.delete(d,rem)                 
                                
                return  rem, d, Nmin
            
        if index == 1:
                rem = self.StaticFailure()
                d = np.zeros(len(self.Damage))
                Nmin=0
                d=np.delete(d,rem) 
                return  rem, d, Nmin
       

#%%      
    def StaticAnalysis(self,el_ids):    
        

        
        return  np.nanargmax(self.SMax)
        
        
        
#%% Pure tensile Model
        
    def StaticFailure(self):
 
        return  np.nanargmax(self.SMax)        
        
        