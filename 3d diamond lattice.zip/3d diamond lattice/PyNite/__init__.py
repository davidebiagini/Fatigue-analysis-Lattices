# -*- coding: utf-8 -*-
"""
Created on Tue Nov  7 19:08:48 2017

@author: D. Craig Brinck, SE
"""

# Select libraries that will be imported into PyNite for the user
from PyNite.FEModel3D import FEModel3D
