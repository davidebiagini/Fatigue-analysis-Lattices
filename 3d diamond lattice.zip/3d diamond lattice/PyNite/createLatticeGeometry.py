# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 13:56:58 2019

@author: davidebiagini
"""
from matplotlib import pyplot as plt
from PyNite import FEModel3D
from PyNite import Visualization
#from PyNite import FatigueAnalysis
import math as mt
import numpy as np


#%%
class createLatticeGeometry():
    
    def __init__(self,Geometry,repx,repy,repz,scaling):
        
             self.Geometry=Geometry
             self.repx=repx
             self.repy=repy
             self.repz=repz
             self.scaling=scaling
    
#%%   
    def createLattice(self):    

      if self.Geometry == 'Diamond':
          
          Atopface = (self.repx[len(self.repx)-1]+1*self.scaling)*(self.repy[len(self.repy)-1]+1*self.scaling)
          Ztop = self.repz[len(self.repz)-1]+1*self.scaling
          cellnum= 0 
          nodelist= []
          conn= []
          n= 14 #Number of nodes in a single cell 
          for k in self.repz:
              for j in self.repy:
                  for i in self.repx:
                                   
                    nodelist.append([0+n*cellnum,cellnum,[self.scaling*0+i,self.scaling*0+j,self.scaling*0+k]])         
                    nodelist.append([1+n*cellnum,cellnum,[self.scaling*1+i,self.scaling*1+j,self.scaling*0+k]])
                    nodelist.append([2+n*cellnum,cellnum,[self.scaling*1+i,self.scaling*0+j,self.scaling*1+k]])
                    nodelist.append([3+n*cellnum,cellnum,[self.scaling*0+i,self.scaling*1+j,self.scaling*1+k]])
                    nodelist.append([4+n*cellnum,cellnum,[self.scaling*0.5+i,self.scaling*0.5+j,self.scaling*0+k]])
                    nodelist.append([5+n*cellnum,cellnum,[self.scaling*0.5+i,self.scaling*0+j,self.scaling*0.5+k]])
                    nodelist.append([6+n*cellnum,cellnum,[self.scaling*1+i,self.scaling*0.5+j,self.scaling*0.5+k]])
                    nodelist.append([7+n*cellnum,cellnum,[self.scaling*0.5+i,self.scaling*1+j,self.scaling*0.5+k]])
                    nodelist.append([8+n*cellnum,cellnum,[self.scaling*0+i,self.scaling*0.5+j,self.scaling*0.5+k]])
                    nodelist.append([9+n*cellnum,cellnum,[self.scaling*0.5+i,self.scaling*0.5+j,self.scaling*1+k]])
                    nodelist.append([10+n*cellnum,cellnum,[self.scaling*0.25+i,self.scaling*0.25+j,self.scaling*0.25+k]])
                    nodelist.append([11+n*cellnum,cellnum,[self.scaling*0.75+i,self.scaling*0.75+j,self.scaling*0.25+k]])
                    nodelist.append([12+n*cellnum,cellnum,[self.scaling*0.75+i,self.scaling*0.25+j,self.scaling*0.75+k]])
                    nodelist.append([13+n*cellnum,cellnum,[self.scaling*0.25+i,self.scaling*0.75+j,self.scaling*0.75+k]])            
                    cellnum+=1    
                                                           
        
          
          nodelist=self.RemoveRepeated(nodelist) 
          z=cellnum
          cellnum=0
          for cellnum in range(z):
                                     
                    conn.append([[nodelist[0+n*cellnum][0], nodelist[10+n*cellnum][0]],cellnum])            
                    conn.append([[nodelist[4+n*cellnum][0], nodelist[10+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[5+n*cellnum][0], nodelist[10+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[8+n*cellnum][0], nodelist[10+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[1+n*cellnum][0], nodelist[11+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[4+n*cellnum][0], nodelist[11+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[6+n*cellnum][0], nodelist[11+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[7+n*cellnum][0], nodelist[11+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[2+n*cellnum][0], nodelist[12+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[5+n*cellnum][0], nodelist[12+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[6+n*cellnum][0], nodelist[12+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[9+n*cellnum][0], nodelist[12+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[3+n*cellnum][0], nodelist[13+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[7+n*cellnum][0], nodelist[13+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[8+n*cellnum][0], nodelist[13+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[9+n*cellnum][0], nodelist[13+n*cellnum][0]],cellnum])
               
          return conn,nodelist,Atopface,Ztop         
      
#%% Remove repeated nodes frome nodelist vector
    
    def RemoveRepeated(self,nodelist):   
          s=[]
          for i in range(len(nodelist)):
                s.append(nodelist[i][2])          
                nonrepeatednodes1 = []
          for i in s:
                if i not in nonrepeatednodes1:
                     nonrepeatednodes1.append(i)
          nonrepeatednodes=[]
          for i in range(len(nonrepeatednodes1)):
                     nonrepeatednodes.append([nonrepeatednodes1[i],i])
          
  #change id of repeated nodes give the same id to nodes pointing at the same coordinates
  
          for i in range(len(nodelist)):
                for j in range(len(nonrepeatednodes)):
                      if nodelist[i][2] ==  nonrepeatednodes[j][0]:
                            nodelist[i][0] = nonrepeatednodes[j][1]
                
          return nodelist
        
#%%        
    def UnrepeatingVector(self,vec):
       vec1=[]
       for i in vec:
          if i not in vec1:
                   vec1.append(i) 
       return vec1
#%%

    def CreateGradingAreavec(self,vec,conn,A):
          
          n=1
          elements=[]
          areas=[]
          vecz=np.linspace(0,max(self.repz)+1,4*(max(self.repz)+1)+1)
          factor1=np.linspace(n*A,A,int(0.5*(len(vecz)-1)))
          factor2=np.linspace(A,n*A,int(0.5*(len(vecz)-1)))
          factor=np.concatenate((factor1,factor2),axis=None)
          
          for x in conn:           
             elements.append([vec[x[0][0]][3],vec[x[0][1]][3]]) 
          
            
          for y in elements:
              for i in range(len(vecz)):
                  if max(y) == vecz[i]:
                      areas.append(float(factor[i-1]))
           
          areas1=[]
          for i in range(len(areas)) :          
                      areas1.append(np.random.normal(areas[i],0.0005,1))
                      
            
          return areas

#%% Add nodes and elements to the 3d lattice
  
    def isertinFEModel(self, conn, nodelist, E, G, r):   

        
         MomentFrame = FEModel3D()
         MomentFrameSmin = FEModel3D()
         vect=[]         
         #non repeating nodes for nodes introduction
         for x in range(len(nodelist)):
             vect.append(("{0}".format(nodelist[x][0]),nodelist[x][2][0],nodelist[x][2][1],nodelist[x][2][2]))       
         vect = self.UnrepeatingVector(vect)         
         #introduce nodes in the system, id from nodelist vec for connectivity construction
         for x in vect:
            MomentFrame.AddNode("{0}".format(x[0]),x[1],x[2],x[3])  
            MomentFrameSmin.AddNode("{0}".format(x[0]),x[1],x[2],x[3])   
         
         A = mt.pi*(r**2)   
         areas = np.asarray(self.CreateGradingAreavec(vect,conn,A))       
         radius = np.sqrt((1/np.pi)*areas)
         Iy = 0.25*mt.pi*np.power(radius,4)
         Iz = Iy
         J= 0.5*mt.pi*np.power(radius,4)  
                 
         k=0  
         el_ids=[]
         initial_el=[]
                  
         for x in conn:
             
             MomentFrame.AddMember("{0}".format(k),"{0}".format(x[0][0]),"{0}".format(x[0][1]) , E,  G,  Iy[k], Iz[k], J[k], areas[k]) 
             MomentFrameSmin.AddMember("{0}".format(k),"{0}".format(x[0][0]),"{0}".format(x[0][1]),  E,  G,  Iy[k], Iz[k], J[k], areas[k]) 
             el_ids.append(k)
             initial_el.append(k)  
             k+=1    
         initial_el
                               
         return  el_ids,initial_el,MomentFrame,MomentFrameSmin
         
#%%
        
        
    def createLattice2D(self):    

      if self.Geometry == 'Diamond':
          
          Atopface = (self.repx[len(self.repx)-1]+1*self.scaling)
          Ztop = self.repz[len(self.repz)-1]+6*self.scaling 
          cellnum= 0 
          nodelist= []
          conn= []
          n= 7 #Number of nodes in a single cell 
          for k in self.repz:

                  for i in self.repx:
                                   
                    nodelist.append([0+n*cellnum,cellnum,[self.scaling*0+i,0,self.scaling*0+k]])         
                    nodelist.append([1+n*cellnum,cellnum,[self.scaling*0+i,0,self.scaling*2+k]])
                    nodelist.append([2+n*cellnum,cellnum,[self.scaling*2+i,0,self.scaling*3+k]])
                    nodelist.append([3+n*cellnum,cellnum,[self.scaling*-2+i,0,self.scaling*3+k]])
                    nodelist.append([4+n*cellnum,cellnum,[self.scaling*2+i,0,self.scaling*5+k]])
                    nodelist.append([5+n*cellnum,cellnum,[self.scaling*-2+i,0,self.scaling*5+k]])
                    nodelist.append([6+n*cellnum,cellnum,[self.scaling*0+i,0,self.scaling*6+k]])
       
                    cellnum+=1    
                                                           
        
          
          nodelist=self.RemoveRepeated(nodelist) 
          z=cellnum
          cellnum=0
          for cellnum in range(z):
   
              if abs((cellnum+1) % 5) <= 0.001 :
                    
                  
                    conn.append([[nodelist[0+n*cellnum][0], nodelist[1+n*cellnum][0]],cellnum])            
                    conn.append([[nodelist[1+n*cellnum][0], nodelist[2+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[1+n*cellnum][0], nodelist[3+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[2+n*cellnum][0], nodelist[4+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[3+n*cellnum][0], nodelist[5+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[4+n*cellnum][0], nodelist[6+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[5+n*cellnum][0], nodelist[6+n*cellnum][0]],cellnum])
                    
                    
              else:      
                    conn.append([[nodelist[0+n*cellnum][0], nodelist[1+n*cellnum][0]],cellnum])            
                    conn.append([[nodelist[1+n*cellnum][0], nodelist[2+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[1+n*cellnum][0], nodelist[3+n*cellnum][0]],cellnum])
#                   conn.append([[nodelist[2+n*cellnum][0], nodelist[4+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[3+n*cellnum][0], nodelist[5+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[4+n*cellnum][0], nodelist[6+n*cellnum][0]],cellnum])
                    conn.append([[nodelist[5+n*cellnum][0], nodelist[6+n*cellnum][0]],cellnum])


          return conn,nodelist,Atopface,Ztop                 
        

        
        
        
