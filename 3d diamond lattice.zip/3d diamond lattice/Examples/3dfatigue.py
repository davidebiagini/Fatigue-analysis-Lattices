# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 16:15:35 2019

@author: davidebiagini
"""
from matplotlib import pyplot as plt
from PyNite import FEModel3D
from PyNite import Visualization
from PyNite import FatigueAnalysis
from PyNite import createLatticeGeometry
import math as mt
import numpy as np


#%% cycle leading to one failure
    
def  FailureCycle(el_ids,F,j,D,R,C,b) :       

    MomentFrame.AddForceTopPlate(F,Ztop)    
    MomentFrame.Analyze() 
    MomentFrameSmin.AddForceTopPlate(F*R,Ztop)    
    MomentFrameSmin.Analyze()  
    Smax=np.asarray(MomentFrame.findMaxStress())
    Smin=np.asarray(MomentFrameSmin.findMaxStress())
    Fatigue.append(FatigueAnalysis.FatigueAnalysis(Smax,Smin,D))  
    disp_upper_plate=MomentFrame.Find_upper_disp(Ztop)        
    MomentFrame.AddForceTopPlate(-F,Ztop)
    MomentFrameSmin.AddForceTopPlate(-F*R,Ztop)
            
    rem, d, Nmin= Fatigue[j].FailureAnalysis(C,b,el_ids)   

    MomentFrame.checkRemoveElNode("{0}".format(el_ids[rem]))
    MomentFrameSmin.checkRemoveElNode("{0}".format(el_ids[rem]))  
       
        
    return  el_ids, d, Nmin, disp_upper_plate,rem

#%% Material Properties          
E = 113000 # elasticity modulus
v = 0.3 #Poisson ratio
G= E/(2*(1+v)) 

#Circular cross sectional ligament
r = 0.1  #radius of  the average lattice ligament

#Properties of the beam element
A = mt.pi*(r**2) 
Iy = 0.25*mt.pi*(r**4)
Iz = Iy
J= 0.5*mt.pi*(r**4)   

#Total Force on the upper plate
F= 50.5

number_of_failures = 20
removals=[]
C=1/860
b=-(1/0.04603)
R=0.7

#Lattice generation Class
#List the number of repetition (taking distance between cells=1)

repx=[0,1,2] 
repy=[0,1,2]
repz=[0,1,2]
scaling=1

#Module for the initialization and meshing of lattice geometry

geometry= createLatticeGeometry.createLatticeGeometry('Diamond',repx,repy,repz,scaling)
conn,nodelist,Atopface,Ztop = geometry.createLattice()
el_ids, initial_el, MomentFrame, MomentFrameSmin= geometry.isertinFEModel(conn, nodelist, E, G, r)
MomentFrame.AddVincula(0)
MomentFrameSmin.AddVincula(0)


#initializations    
NumCycle=[]
top_plate_disp=[]
displacement_top_plate=[]
life=0
# Initialize damage vector    
D=[]
for i in range(len(el_ids)):
    D.append(0)   
removals1=[]   
D=np.asarray(D)   
Fatigue = list()        
for j in range(number_of_failures):
    #initialize module for fatigue calculations           
    el_ids, d, Nmin, disp_upper_plate,rem= FailureCycle(el_ids,F,j,D,R,C,b) 
    
#    print(disp_upper_plate)
    D=d 
    life=life+Nmin #Fatigue Life 
    print(life)
    removals.append(el_ids[rem])
    removals1.append(rem)
    del el_ids[rem]
    #upgrade displacement top plate
    displacement_top_plate.append(disp_upper_plate)
      
Visualization.RenderModel(MomentFrame)   
       