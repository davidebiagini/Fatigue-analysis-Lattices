# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 10:38:08 2019

@author: davidebiagini
"""

#Fatigue analysis Class for fast vectorizing

#from numpy import zeros, delete, insert, matmul, subtract
#from numpy.linalg import inv
#import statistics
import numpy as np
from sympy import *

# %%
class FailureAnalysis():  #This class handles the removal of the single rods with different models for static and Fatique Failure
    
    def __init__(self,D,Areas,Shear1,Moment1,Axial1,Shear2,Moment2,Axial2):
    
        self.Damage = D   # vector collecting damage of every element   
        self.Areas= Areas    # vector collecting the cross sectional areas of every moment      
              
        #Maximum stress in Fatigue cycle
        self.Shear1 = Shear1  # vector collecting shear force for every element
        self.Moment1= Moment1  # vector collecting maximum moment for every element
        self.Axial1= Axial1   # vector collecting Axial force for every element
              
        #Minimum stress in Fatigue cycle
        self.Shear2 = Shear2  # vector collecting shear force for every element
        self.Moment2= Moment2  # vector collecting maximum moment for every element
        self.Axial2= Axial2   # vector collecting Axial force for every element
        
        
#%%   Generate a Gaussian distributed vector around a mean value and variance
         
    def GenerateGaussian(self, mean, var, numel):        #This can be used to model imperfections of lattice structure
        
         s = np.random.normal(mean, var, numel)
         
         return s          
# %% 
   
    def Stresses(self): #The maximum principal tensile stress here is calculated
        
        Moment1= np.asarray(self.Moment1) # vectorize every operation 
        Axial1=  np.asarray(self.Axial1) 
        Moment2= np.asarray(self.Moment2) # vectorize every operation 
        Axial2=  np.asarray(self.Axial2)       
        Areas=   np.asarray(self.Areas)
        radius=  Areas/2
        
        Inertia= (1/12)*np.power(2*radius,3)
       
        
        Stress1= np.add( np.multiply (Axial1,np.power(Areas,-1)) , np.multiply( Moment1 ,np.multiply( radius,np.power(Inertia,-1) )))
        Stress2= np.add( np.multiply (Axial2,np.power(Areas,-1)) , np.multiply( Moment2 ,np.multiply( radius,np.power(Inertia,-1) )))

        return Stress1, Stress2      
              
      
# %%    
    def Correct_Stress_cycle(self,Smax,Smin):  # In the case of Fatigue testing This function corrects Smax Smin in order to have the element Max and
                                               # Min stress instead of the specimen max and min stress (they not always correspond)       
        S=[]
        s=[]
        
        for i in range(len(Smax)):
            if Smax[i] >= Smin[i]:
               S.append(Smax[i])
               s.append(Smin[i])
               
            if Smax[i] < Smin[i]:
               s.append(Smax[i])
               S.append(Smin[i])
               
        return S,s       


# %% 
    def MeanStressCorrection(self,Smax,Smin,Yeld):  #Goodman Relation is used
        
        
        DS=np.subtract(Smax,Smin)*0.5
        MeanStress=(np.add(Smin,Smax))*0.5           
        Sigmaeff= np.multiply(DS,1/(1 - MeanStress*(Yeld**(-1))))
        
#        for i in range(len(Sigmaeff)):
#         if Sigmaeff[i] < 0 :
#             Sigmaeff[i] = 115
        

        return Sigmaeff,DS
    
#%%        
    def MinerRule(self,C,Sigmaeff,b,D,DS):     
        C=1/115
       # C=self.GenerateGaussian(C,0.07*C,len(Sigmaeff)) if imperfection in properties wants to be used
       
        n=np.power(C*Sigmaeff,b)            
        for i in range(len(n)):
                if np.isnan(n[i]):
                    n[i]=1e150
            
            
        N=np.multiply(n,(1-D))    # Vector of remaining life        
        Nmin=np.nanmin(N)         # Minimum remaining life element life            
        d = Nmin*np.power(n,-1)     # Damage vector updating
        
        return Nmin,d,N 
        
    
#%%    Fatigue failure modelling   
        
    def FatigueAnalysis(self,C,b,Yeld):
        
        D = np.asarray(self.Damage)          
        S1,S2=self.Stresses()        
        Smax,Smin=self.Correct_Stress_cycle(S1,S2)     
        Sigmaeff,DS=self.MeanStressCorrection(Smax,Smin,Yeld)   
        index=0
        if max(Smax)>=110:
                index=1
        # Two different Models for Static and Fatigue failure
        if index == 0:
            
                
                Nmin,d,N=self.MinerRule(C,Sigmaeff,b,D,DS)
                for i in range(len(d)):
                  if np.isnan(d[i])==True:
                   d[i] = 0    
                
                d=D+d        
                rem=np.nanargmin(N)
                
                d=np.delete(d,rem)        
                print(Nmin)
                return  rem, d, Nmin, max(Smax)
            
        if index == 1:
                rem = self.StaticFailure()
                d = np.zeros(len(D))
                Nmin=0
                d=np.delete(d,rem)  
                
                return  rem, d, Nmin, max(Smax)
    
#%% Pure tensile Model
        
    def StaticFailure(self):

        S,s = self.Stresses()       
        return  np.nanargmax(S)

#%%  Model for static failur that accounts also for shear
        
    def StressDominatedFailure(self, D, shear, Moment, Axial, Inertias):

        S1=[]

        for i in range(len(shear)):
             
             radius=(4*Inertias[i]/np.pi)**(0.25)
             f=[]
             
             for x in np.linspace(-radius,radius,20):
                f.append(0.5*(Moment[i]*x/Inertias[i] + Axial[i]) + \
                (0.25*(Moment[i]*x/Inertias[i] + Axial[i])**(2) + ((self.shear[i]**2)/(4*Inertias[i]**(2)))*\
                ((radius**2)/4 - x**2)**2)**(0.5))             
             S1.append(max(f))
             
              
        return  np.nanargmax(S1)










        
        
        