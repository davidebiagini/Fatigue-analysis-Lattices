# -*- coding: utf-8 -*-
"""
Created on Fri Nov  1 12:22:23 2019

@author: davidebiagini
"""
import numpy as np
import math as mt
class CreateLattice():
    
    
    def __init__(self,x_rep,y_rep,scaling,E,A):
              
    
        self.x_rep = x_rep 
        self.y_rep = y_rep
        self.scaling  = scaling
        self.E=E
        self.A=A
               
    
#%%   
        
    #this function allows the user to create functionally graded lattices:
    
    #INPUTS---> x, y coordinates of the middle of a specific element inside the specimen
    #            x in [0,x length]
    #            y in [0,y length]
    #OUTPUT---> cross sectional Area of the element depending on its position in space
    
    
    def FindArea(self,x,y):
        
        #self.A is the nominal value of the cross section already stored in the class
        A = self.A
        
        # if a andom cross sectional area with mean value = self.A needs to e assigned 
        #A = float(np.random.normal(self.A, 0.04, 1))

        # define an ellipse area inside the specimen centered in x mean y mean (a circle can be created using a=b)
        xmean=40
        ymean=40
        alpha=0 # angle of rotation of th ellipse
        # Ellipse
        a= 20  # horizontal semiaxis
        b= 20   # vertical semiaxis
    
        z=(((x-xmean)*np.cos(alpha)+(y-ymean)*np.sin(alpha))**2/a**2) + (((x-xmean)*np.sin(alpha)-(y-ymean)*np.cos(alpha))**2)/b**2
#               
        if z<=1:
#             A=0.1*self.A #to make an imperfection by reducing areas
              A = float(np.random.normal(self.A, 0.04, 1))

#       To create grading based on synusoida functions
              
        x=x*np.pi/180 #working with radiants could be easier
        y=y*np.pi/180
       
        
#        Hierarchy out of phase
#        A= A*(1.1 + 0.4*np.sin(10*x)*np.sin((10*y)))
        
#        Hierarchy in phase        
        A= A*(1.1 + 0.3*np.sin(16*(x)) + 0.3*np.cos((16*y)))    
 
#        Vertical gradient       
#        A= A*(1.1 + 0.5*np.cos((12*y)))  

#        Horizontal gradient                
#        A= A*(1 + 0.2*np.cos((4*x))+ 0.2*np.cos((4*y)))    
        
               
        A=A*self.E
        
        return A
    
#%%
    def GenerateLattice(self):     
        
        vec=[]   
        vect=[]


        ztop=self.y_rep*6

        iindex=[]
        jindex=[]
        
        for i in range(self.x_rep):           
            jindex.append(4*i)
            
        for i in range(self.y_rep):            
            iindex.append(6*i)  
       
        #creation of hexagonal lattice from coordinates cellsize =1
        
        for i in iindex: 
          for j in jindex: 
              
             if abs(j - jindex[len(jindex)-1]) <= 0.01 :
                 
               vec1=([[0+j, 0+i],[0+j, 2+i]],\
               [[0+j, 2+i], [2+j, 3+i]],\
               [[0+j, 2+i], [-2+j, 3+i]],\
               [[2+j, 3+i], [2+j, 5+i]],\
               [[-2+j, 3+i], [-2+j, 5+i]],\
               [[-2+j, 5+i], [0+j, 6+i]],\
               [[2+j, 5+i], [0+j, 6+i]])                
               vect.extend(vec1)    
 
             #remve last elment of every row 
             else:
               
                vec1=([[0+j, 0+i],[0+j, 2+i]],\
                [[0+j, 2+i], [2+j, 3+i]],\
                [[0+j, 2+i], [-2+j, 3+i]],\
#               [[2+j, 3+i], [2+j, 5+i]],\
                [[-2+j, 3+i], [-2+j, 5+i]],\
                [[-2+j, 5+i], [0+j, 6+i]],\
                [[2+j, 5+i], [0+j, 6+i]])    
              
                vect.extend(vec1)
              
        vec2=[]               
        for k in vect: 
                                                                                                                          
                       vec2.append(self.FindArea((k[0][0]+k[1][0])/2,(k[0][1]+k[1][1])/2))
                       
                       
        vec3=[]          
        for i in range(len(vec2)):          
                       vec3.append([vect[i],vec2[i]])                       
        #vec = structure containing data of every element      
        vec.extend(vec3) 
        Atop=self.x_rep*6*self.y_rep*4
        
        return vec,Atop,ztop,self.x_rep*4
    