from anastruct import SystemElements
import numpy as np
import math as mt
from matplotlib import pyplot as plt
from anastruct import CreateLattice
from anastruct import FatigueAnalysis

E=2.29e9
radius=0.1
A= mt.pi*(radius**2) #element area
I= 0.25*(mt.pi*(radius**4))

ss = SystemElements()
ss.add_element(location=[[0, 0], [0, 2]], EA=E*A, EI=E*I)
ss.add_element(location=[[0, 2], [2, 3]], EA=E*A, EI=E*I)
ss.add_element(location=[[2, 3], [2, 5]], EA=E*A, EI=E*I)
ss.add_element(location=[[2, 5], [0, 6]], EA=E*A, EI=E*I)
ss.add_element(location=[[0, 6], [-2, 5]], EA=E*A, EI=E*I)
ss.add_element(location=[[-2, 5], [-2, 3]], EA=E*A, EI=E*I)
ss.add_element(location=[[0, 2], [-2, 3]], EA=E*A, EI=E*I)

vincula=[]
load=[]
ztop=6
F=10

L=ss.nodes_range('y')       
for i in range(len(L)):
         if L[i] == 0:
            vincula.append(i+1)
         if L[i] == ztop:
            load.append(i+1)    
print(load)

ss.point_load(load,Fx=0,Fy=F,rotation=0)        
ss.add_support_fixed(vincula)

ss.solve()
ss.show_structure()
ss.show_reaction_force()
ss.show_axial_force()
ss.show_shear_force()
ss.show_bending_moment()
ss.show_displacement()


