$PYTHON setup.py install   
