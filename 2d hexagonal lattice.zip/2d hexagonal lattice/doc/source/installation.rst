Installation
============

You can install anaStruct with pip!

::

    $ pip install anastruct

It takes a while before new features are added in the official PyPI index. So if you want the latest features,
install from github.

::

    $ pip install git+https://github.com/ritchie46/anaStruct.git