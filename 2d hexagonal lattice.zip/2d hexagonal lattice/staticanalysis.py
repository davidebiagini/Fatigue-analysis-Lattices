# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 14:20:48 2019

@author: davidebiagini
"""

"""
Created on Mon Sep 16 13:34:07 2019
@author: DAVIDE BIAGINI
"""

from anastruct import SystemElements
import numpy as np
import math as mt
from matplotlib import pyplot as plt
from anastruct import CreateLattice
from anastruct import FailureAnalysis

def failure_cycle(vec,j,Atop,ztop,Ftot,E):
     #create elements and nodes mesh  
     
     Areas=[]
     for m in range(len(vec)):         
        if m<len(vec):
           m=int(m)
            
           Areas.append((vec[m][1]/E))                               
           objs[j].add_element(location=[vec[m][0][0],vec[m][0][1]],EA=vec[m][1],EI=(1/(4*mt.pi*E))*(vec[m][1]**2))
                
     #insert BC from coordinates      
     vincula=[]
     load=[]     
     L=objs[j].nodes_range('y')  

     for i in range(len(L)):
         if L[i] == 0:
            vincula.append(i+1)
         if abs(L[i] - ztop) <= 0.01 :
            load.append(i+1)    

     F=Ftot/len(load)
     objs[j].point_load(load,Fx=0,Fy=F,rotation=0)        
     objs[j].add_support_roll(vincula,'x')
     objs[j].add_support_spring(vincula[0],1,100)     
     objs[j].show_structure(verbosity=1)
       
     
#    solve the equation      
     objs[j].solve()       
     numel= len((objs[j].element_map))        
     disp=[]
     for i in load:
        disp.append(objs[j].get_node_displacements(node_id=i).get('uy'))
     print(disp)
     mean =(sum(disp)/len(disp))     
     #Postprocessing    
  
     shear=[]
     Moment=[]
     Axial=[]
     
     for i in range(numel):
             
             Axial.append(objs[j].get_element_results(element_id=i+1).get('N'))         
             shear.append(objs[j].get_element_results(element_id=i+1).get('q'))
             M_max=(objs[j].get_element_results(element_id=i+1).get('Mmax'))
             M_min=abs((objs[j].get_element_results(element_id=i+1).get('Mmin')))                         
             M_max1=max(abs(M_max),abs(M_min))                      
             Moment.append(M_max1)             
    
     Fatigue.append(FailureAnalysis.FailureAnalysis (D, Areas, shear, Moment, Axial, 0, 0, 0))       
     z=Fatigue[j].StaticFailure()
             
     return  z,mean 

#%%create a damage vector                   
E=2.29e9
radius=0.1
A= mt.pi*(radius**2) #element area
I= 0.25*(mt.pi*(radius**4))
R=0.1
Ftot=1
numfail=3
repx=5
repy=1

Geom = CreateLattice.CreateLattice(repx, repy, 1,E,A)
vec,Atop,ztop= Geom.combinedgradient()

Fatigue=list()
objs = list()
objsmin = list()

for f in range(numfail+1):
    objs.append(SystemElements(EI=E*I, EA=E*A))   #default values
D=[]
for i in range(len(vec)):
    D.append(0)     
##failure cycles        
Numcycle=[]
displacement_upper=[]   

for j in range(numfail):           
    z,mean = failure_cycle(vec, j, Atop, ztop, Ftot, E)         
    del vec[z]         
    displacement_upper.append(-mean)
    

   