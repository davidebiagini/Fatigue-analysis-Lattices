
"""
Created on Mon Sep 16 13:34:07 2019
@author: DAVIDE BIAGINI
"""

from anastruct import SystemElements
import numpy as np
import math as mt
from matplotlib import pyplot as plt
import matplotlib
from anastruct import CreateLattice
from anastruct import FailureAnalysis

#Element removal to avoid singularities at the extrema
#this function has the only use of not arrest the analysis after early local singularities

def avoidSingularity(vec,z,d,ztop,xlen):
    
    k=-1
    xlen=xlen-2
    
    if ((vec[z][0][0][0]==(xlen-2)  or vec[z][0][1][0]==(xlen-2)) and (vec[z][0][0][1]==ztop or vec[z][0][1][1]==ztop))or\
       ((vec[z][0][0][0]==0 or vec[z][0][1][0]==0) and (vec[z][0][0][1]==ztop or vec[z][0][1][1]==ztop)):
                     
        del vec[z]
        for i in range(len(vec)):
        
            if ((vec[i][0][0][0]==xlen or vec[i][0][1][0]==xlen) and (vec[i][0][0][1]==ztop-1 or vec[i][0][1][1]==ztop-1)) and\
               ((vec[i][0][0][0]==(xlen-2) or vec[i][0][1][0]==(xlen-2) ) and (vec[i][0][0][1]==ztop or vec[i][0][1][1]==ztop)):
                  k=i
                        
            if ((vec[i][0][0][0]==-2 or vec[i][0][1][0]==-2) and (vec[i][0][0][1]==ztop-1 or vec[i][0][1][1]==ztop-1)) and\
               ((vec[i][0][0][0]==0 or vec[i][0][1][0]==0) and (vec[i][0][0][1]==ztop or vec[i][0][1][1]==ztop)):                  
                  k=i
        del vec[k]
        d=np.delete(d,k) 
        
    else :
       del vec[z]    
        
    return vec, d

#%%
def failure_cycle(vec,j,Atop,R,D,ztop,Ftot, E, C, b, Yeld):
    
#  create elements and nodes mesh     
     Areas=[]
     
     for m in range(len(vec)):         
        if m<len(vec):
           m=int(m)
           
           #This uses moment of inertia of rectangular cross sections
           
           objs[j].add_element(location=[vec[m][0][0],vec[m][0][1]],EA=vec[m][1],EI=E*(1/12)*((vec[m][1]/E))**3) 
           objsmin[j].add_element(location=[vec[m][0][0],vec[m][0][1]],EA=vec[m][1],EI=E*(1/12)*((vec[m][1]/E))**3)           
           Areas.append((vec[m][1]/E))

#  insert BC from coordinates      
     vincula=[]
     load=[]
     L=objs[j].nodes_range('y')       
     for i in range(len(L)):
         if L[i] == 0:
            vincula.append(i+1)
         if L[i] == ztop:
            load.append(i+1)    
    
     F=Ftot/len(load)
     Fmin=F*R
     objs[j].point_load(load,Fx=0,Fy=F,rotation=0)      
     objsmin[j].point_load(load,Fx=0,Fy=Fmin,rotation=0) 
     
#     objs[j].add_support_fixed(vincula)
#     objsmin[j].add_support_fixed(vincula)
     
     objs[j].add_support_roll(vincula,'x')
     objs[j].add_support_spring(vincula[0],1,100)
     objsmin[j].add_support_roll(vincula,'x')
     objsmin[j].add_support_spring(vincula[0],1,100)     
     
#    solve the equation      
     objs[j].solve()
     objsmin[j].solve()        


     numel= len((objs[j].element_map))        
     disp=[]

     for i in load:
        disp.append(objs[j].get_node_displacements(node_id=i).get('uy'))     
     mean =(sum(disp)/len(disp))     
     #Postprocessing    
     Axial1=[]
     Shear1=[]
     Moment1=[]
     Axial2=[]
     Shear2=[]
     Moment2=[]
     
     #Maximum stress level
     for i in range(numel):
             Axial1.append(objs[j].get_element_results(element_id=i+1).get('N'))         
             Shear1.append(objs[j].get_element_results(element_id=i+1).get('q'))
             M_max=(objs[j].get_element_results(element_id=i+1).get('Mmax'))
             M_min=abs((objs[j].get_element_results(element_id=i+1).get('Mmin')))                         
             M_max1=max(abs(M_max),abs(M_min))                      
             Moment1.append(M_max1)     

     #Minimum stress level                  
     for i in range(numel):                  
             Axial2.append(objsmin[j].get_element_results(element_id=i+1).get('N'))         
             Shear2.append(objsmin[j].get_element_results(element_id=i+1).get('q'))
             M_max=(objsmin[j].get_element_results(element_id=i+1).get('Mmax'))
             M_min=abs((objsmin[j].get_element_results(element_id=i+1).get('Mmin')))                         
             M_max1=max(abs(M_max),abs(M_min))                      
             Moment2.append(M_max1)     
   
    
     Fatigue.append(FailureAnalysis.FailureAnalysis(D,Areas,Shear1,Moment1,Axial1,Shear2,Moment2,Axial2))
     z, d, Nmin,Smax =Fatigue[j].FatigueAnalysis(C,b,Yeld)
     vec, d = avoidSingularity(vec,z,d,ztop,xlen)
         
     return  z,d,Nmin,mean,vec,Smax

#%% ANALYSIS
     
# material properties             
E=69000
Yeld = 110

# ligament

r=0.1
A=(2*r)*1
I=((2*r)**(3))/12

#fatigue 

R = 0.1      #R ratio       
C = 1/155    #Basquin parameters
b = -1/0.096    

#Creation of the lattice 
repx=10 #number of repetitions in the x direction
repy=15 #number of repetitions in the y direction

#total force in the upper nodes # + tension # - compression
Ftot=1

#number of failures
numfail=1

# Creation of the lattice structure module
Geom = CreateLattice.CreateLattice(repx, repy, 1,E,A)
vec,Atop,ztop,xlen= Geom.combinedgradient()

#create an Object for each failure 
Fatigue=list()
objs = list()
objsmin = list()

for f in range(numfail+1):
    objs.append(SystemElements(EI=E*I, EA=E*A))   #default values
    objsmin.append(SystemElements(EI=E*I, EA=E*A))


# Initialize damage vector    
D=[]
for i in range(len(vec)):
    D.append(0)   
D=np.asarray(D) 
   
##failure cycle   
Numcycle=[]
life=0
displacement_upper=[]   
life=0
stress=[]
for j in range(numfail):           
    z,d,Nmin,mean,vec,Smax = failure_cycle(vec, j, Atop, R, D, ztop, Ftot, E, C, b, Yeld)            
    D = d   
      
    displacement_upper.append(-mean)
    life=life+Nmin     
    Numcycle.append(life) 
    stress.append(Smax)
    
print(life) 
print(Numcycle)
print(stress)


objs[j].show_structure(verbosity=1)
#pot mean displacement of upper plate 

#for i in progresslife:
#    v.append(mt.log10(i))
#plt.plot(v,displacement_upper) 



    